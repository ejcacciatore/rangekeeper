# SuperClaw — Productivity Operating System

**A meta-framework for building businesses at high velocity.**

SuperClaw encodes decision-making patterns, automation scripts, and execution playbooks used to manage multiple businesses simultaneously (CalcGuard, Sapinover, World Specialties, KeyLedger, etc.).

---

## What's Inside

### 📚 **Frameworks**
- **SUPERCLAW.md** — Core productivity principles and decision matrices
- **BUSINESS-MODELS.md** — Revenue frameworks for SaaS, consulting, ecommerce
- **GTM-PLAYBOOKS.md** — Go-to-market strategies by business type
- **DECISION-TREES.md** — Build vs Buy vs Ignore, When to Hire, When to Automate

### 🛠️ **Tools**
- **scripts/scaffold** — Project initialization templates
- **scripts/deploy** — Common deployment patterns
- **scripts/analyze** — Competitive analysis automation
- **scripts/content** — Content generation workflows

### 📋 **Templates**
- **templates/repos/** — Repo structures for SaaS, API, ecommerce
- **templates/docs/** — README, CONTRIBUTING, API docs
- **templates/sales/** — Pitch decks, one-pagers, case studies
- **templates/legal/** — Terms, Privacy, SLAs

### 🤖 **Integrations**
- **openclaw/** — OpenClaw-specific workflows and sub-agent patterns
- **mcp/** — MCP server templates for common APIs
- **github/** — GitHub Actions, issue templates, PR templates

---

## Philosophy

### Revenue > Activity
Every action should have a clear path to revenue. If it doesn't, justify why you're doing it.

### Ship > Perfect
80% solution today > 100% solution next month. Launch, learn, iterate.

### Automate > Repeat
If you'll do it twice, script it. If you'll do it monthly, cron it.

### Leverage > Grind
Code > manual labor. API > manual entry. Sub-agent > doing it yourself.

---

## Quick Start

### Clone the Framework
```bash
git clone git@github.com:YOUR-USERNAME/superclaw.git
cd superclaw
```

### Scaffold a New Project
```bash
./scripts/scaffold saas my-new-project
cd my-new-project
npm install
npm run dev
```

### Use a Template
```bash
cp templates/repos/saas-api/* ~/my-project/
```

### Run an Analysis
```bash
./scripts/analyze competitors "fintech data fabric" --output report.md
```

---

## Structure

```
superclaw/
├── README.md
├── SUPERCLAW.md              # Core framework
├── BUSINESS-MODELS.md        # Revenue frameworks
├── GTM-PLAYBOOKS.md          # Go-to-market strategies
├── DECISION-TREES.md         # Decision matrices
│
├── scripts/
│   ├── scaffold/             # Project generators
│   ├── deploy/               # Deployment automation
│   ├── analyze/              # Competitive analysis
│   └── content/              # Content generation
│
├── templates/
│   ├── repos/                # Repo structures
│   ├── docs/                 # Documentation templates
│   ├── sales/                # Sales collateral
│   └── legal/                # Legal templates
│
├── openclaw/
│   ├── workflows/            # Common workflows
│   ├── sub-agents/           # Sub-agent patterns
│   └── mcps/                 # MCP templates
│
└── examples/
    ├── tax-engine/           # Example: automated tax collection
    ├── keyledger/            # Example: real estate platform
    └── calcguard/            # Example: fintech data fabric
```

---

## Usage Patterns

### Starting a New Business
1. Define the business model (`BUSINESS-MODELS.md`)
2. Choose GTM strategy (`GTM-PLAYBOOKS.md`)
3. Scaffold the repo (`scripts/scaffold`)
4. Build MVP (use templates + OpenClaw sub-agents)
5. Launch and iterate

### Automating Repetitive Work
1. Identify the pattern
2. Write a script in `scripts/`
3. Add it to cron if recurring
4. Document in `SUPERCLAW.md`

### Making Strategic Decisions
1. Consult `DECISION-TREES.md`
2. Apply revenue lens (does it move toward $45K/month?)
3. If unclear, spawn a sub-agent to research
4. Make decision, encode heuristic for next time

---

## Contributing

This is a personal productivity framework, but principles are shareable.

If you find patterns worth encoding:
1. Add to relevant `.md` file
2. Create script/template if reusable
3. Commit with clear message
4. Push to GitHub

---

## License

Private — Rico Cacciatore only (for now)

---

**Built by Claw for Rico — optimized for speed, revenue, and leverage.**
