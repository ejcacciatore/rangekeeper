# SuperClaw Setup — Push to GitHub

## 1. Create GitHub Repo

Go to: https://github.com/new

**Settings:**
- Name: `superclaw`
- Description: `Productivity framework for multi-business operations`
- **Private** (contains business strategies)
- Don't initialize (we have commits already)

Click **Create repository**

---

## 2. Push to GitHub

```bash
cd /home/ubuntu/.openclaw/workspace/superclaw

# Add GitHub remote (replace YOUR-USERNAME)
git remote add origin git@github.com:YOUR-USERNAME/superclaw.git

# Push
git branch -M main
git push -u origin main
```

---

## 3. Verify

Visit: https://github.com/YOUR-USERNAME/superclaw

You should see:
- README.md
- SUPERCLAW.md
- BUSINESS-MODELS.md
- GTM-PLAYBOOKS.md
- Directory structure

---

## 4. Clone to Your Local Machine (Windows)

```bash
# On your Windows machine:
cd C:\Users\ejcac\repos
git clone git@github.com:YOUR-USERNAME/superclaw.git
cd superclaw
```

Now you have it in both places:
- **Server:** `/home/ubuntu/.openclaw/workspace/superclaw/` (I can edit)
- **Local:** `C:\Users\ejcac\repos\superclaw\` (you can edit)

---

## 5. Sync Workflow

**When I make changes (on server):**
```bash
cd superclaw
git add -A
git commit -m "Description of changes"
git push
```

**When you pull (on Windows):**
```bash
cd C:\Users\ejcac\repos\superclaw
git pull
```

**When you make changes (on Windows):**
```bash
git add -A
git commit -m "Your changes"
git push
```

**Then I pull (on server):**
```bash
cd /home/ubuntu/.openclaw/workspace/superclaw
git pull
```

---

## 6. Adding Content to SuperClaw

**From our chats:**
Just tell me: "Add [topic] to SuperClaw"

Examples:
- "Add a decision tree for when to hire vs automate"
- "Add a template for API documentation"
- "Add a GTM playbook for developer tools"

I'll create the content, commit, and push to GitHub.

**From your side (Windows):**
Edit files locally, commit, push. I'll pull when needed.

---

## 7. Using SuperClaw from Other Projects

**Reference from any repo:**
```bash
# In tax-engine, keyledger, etc:
# Just link to SuperClaw principles in docs

# Example in README.md:
"This project follows [SuperClaw principles](https://github.com/YOUR-USERNAME/superclaw)"
```

**Or clone as submodule:**
```bash
# In a project repo:
git submodule add git@github.com:YOUR-USERNAME/superclaw.git _superclaw
```

---

## Next Steps

1. Create GitHub repo
2. Push (commands above)
3. Clone to Windows
4. Tell me what else you want in SuperClaw

I'll continue building it out as we work on projects.

---

**SuperClaw is now your centralized productivity knowledge base.** 🚀
